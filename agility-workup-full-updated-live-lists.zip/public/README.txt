Place static assets here if needed.
